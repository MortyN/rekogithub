<?php 
include("control.php");
?>






</body>
</html>