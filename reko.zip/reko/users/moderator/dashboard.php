<?php 
include("control.php");

?>

<div class="dashboard_content">

<!-- Innhold mellom her -->

</div>