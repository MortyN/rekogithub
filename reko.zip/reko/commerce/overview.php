<?php include("../meny.php"); ?>
<div class="overview_info">
<h1>Våre lokale leverandører</h1>

<p>Under finner du en oversikt over leverandørene som er registrert i din reko ring, klikk på bilde for å
    lese mere om leverandøren, gårdsbruk eller se på hva leverandøren tilbyr.</p>

</div>
<div class="grid-container">
<?php

$sql= "SELECT * FROM users WHERE role='commerce' and status='1' order by RAND();";
$result = mysqli_query($db,$sql) or die("ikke mulig å vise leverandørene");
$xRows = mysqli_num_rows($result);

for($x=1;$x <= $xRows; $x++){
    
    $part=mysqli_fetch_array($result);
    $userID = $part["userID"];
    $image = $part["image"];
    $firstName = $part["firstName"];
    $lastName = $part["lastName"];
    ?>
    <div class="grid-item">
      <a href="profile.php?ID=<?php print($userID);?>"><img src="../img/users/<?php print($userID.'/'.$image);?>"></a>
        <h2><a href='profile.php?ID=<?php print($userID);?>'><?php print($firstName.' '.$lastName);?></a><h2>
    </div>
    <?php

}
?>
</div>