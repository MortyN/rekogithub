<?php include("meny.php"); ?>

<div class="container">
         <div class="hero-image">
            <div class="hero-text">
                <h1>REKO</h1>
                <p>Kjøp kortreist lokal mat!</p>
                <button href="access/regUser.php">Bli med i dag!</button>
            </div>
        </div>
                

                

        <div class="section">
         <div class="section_content" contenteditable="true">
                <h1> Hva er REKO? </h1>
                <p> Lorem, ipsum dolor sit amet consectetur adipisicing elit. Ab, laborum.</p>
                <p>  Lorem ipsum dolor sit, amet consectetur adipisicing elit. Maxime rem ipsum quo, sit et ut incidunt nemo nulla quidem hic?</p>
                <p>  Lorem ipsum, dolor sit amet consectetur adipisicing elit. Impedit, nam.</p>
                <p>  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos cumque cum a aliquam ipsa sequi assumenda ipsum eaque mollitia dolores!</p>
                <p>  Lorem ipsum dolor sit amet consectetur adipisicing elit. A saepe nesciunt harum beatae. Explicabo, officia!</p>
            </div>
        </div>
            

         
       
        <?php include("footer.php"); ?>
        </div>
   
